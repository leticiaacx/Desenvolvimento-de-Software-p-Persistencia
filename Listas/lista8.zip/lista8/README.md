exemplo-dao-jpa
===============

Exemplo de aplicação JPA usando padrão de projeto DAO.

Download
--------
Através do botão "Download ZIP" ou através de um comando "git clone https://github.com/regispires/exemplo-dao-jdbc.git"
O 'git clone' pode ser realizado diretamente através do Eclipse:
- Mudar para a perspectiva para "Git Repository Exploring".
- Clicar no botão Clone Git repository.
- Colar a URI do repositório em Location -> URI.

